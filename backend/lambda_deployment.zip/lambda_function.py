import json
import os
import re
import hashlib
import time
from datetime import datetime
from decimal import Decimal

import boto3
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource("dynamodb")
bedrock = boto3.client("bedrock-runtime")

USERS_TABLE = os.environ.get("USERS_TABLE", "Users")
CONCEPTS_TABLE = os.environ.get("CONCEPTS_TABLE", "SyllabusConcepts")
PROGRESS_TABLE = os.environ.get("PROGRESS_TABLE", "UserConceptProgress")
STUDY_PLAN_TABLE = os.environ.get("STUDY_PLAN_TABLE", "StudyPlan")
NOTEBOOK_TABLE = os.environ.get("NOTEBOOK_TABLE", "ConceptNotebook")
MISTAKE_LOGS_TABLE = os.environ.get("MISTAKE_LOGS_TABLE", "MistakeLogs")
MEMORY_TABLE = os.environ.get("MEMORY_TABLE", "UserLearningMemory")
AI_CACHE_TABLE = os.environ.get("AI_CACHE_TABLE", "AICache")
USAGE_TABLE = os.environ.get("USAGE_TABLE", "UserUsage")
BEDROCK_MODEL_ID = os.environ.get(
    "BEDROCK_MODEL_ID", "anthropic.claude-3-haiku-20240307-v1:0"
)

users_table = dynamodb.Table(USERS_TABLE)
concepts_table = dynamodb.Table(CONCEPTS_TABLE)
progress_table = dynamodb.Table(PROGRESS_TABLE)
study_plan_table = dynamodb.Table(STUDY_PLAN_TABLE)
notebook_table = dynamodb.Table(NOTEBOOK_TABLE)
mistake_logs_table = dynamodb.Table(MISTAKE_LOGS_TABLE)
memory_table = dynamodb.Table(MEMORY_TABLE)
cache_table = dynamodb.Table(AI_CACHE_TABLE)
usage_table = dynamodb.Table(USAGE_TABLE)

MISTAKE_CATEGORIES = {
    "conceptual",
    "formula_recall",
    "calculation",
    "application_logic",
    "exam_trap",
}

TIER_RANK = {"free": 0, "pro": 1, "elite": 2}
TIER_DAILY_LIMITS = {"free": 50, "pro": 200, "elite": 1000}  # Increased limits for better testing


class UsageLimitExceeded(Exception):
    pass


def log_event(level, event_name, **context):
    payload = {
        "ts": datetime.utcnow().isoformat() + "Z",
        "level": level,
        "event": event_name,
        **context,
    }
    print(json.dumps(payload, default=str))


def normalize_tier(subscription_tier):
    tier = str(subscription_tier or "free").strip().lower()
    return tier if tier in TIER_RANK else "free"


def has_tier_access(current_tier, required_tier):
    return TIER_RANK.get(normalize_tier(current_tier), 0) >= TIER_RANK.get(required_tier, 0)


def get_ai_limit_for_tier(subscription_tier):
    return TIER_DAILY_LIMITS.get(normalize_tier(subscription_tier), 5)


def build_cache_key(request_type, user_id, concept_id, mastery, extra=None):
    payload = {
        "request_type": request_type,
        "user_id": user_id,
        "concept_id": concept_id,
        "mastery": int(mastery),
        "extra": extra or {},
    }
    digest = hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()
    return f"{request_type}:{digest}"


def get_cached_response(cache_key):
    result = cache_table.get_item(Key={"cache_key": cache_key})
    item = result.get("Item")
    if not item:
        log_event("debug", "cache_miss", cache_key=cache_key)
        return None
    ttl = int(item.get("ttl", 0))
    if ttl and ttl <= int(time.time()):
        log_event("debug", "cache_expired", cache_key=cache_key)
        return None
    log_event("info", "cache_hit", cache_key=cache_key)
    return item


def save_to_cache(cache_key, response_text, hours=6):
    ttl = int(time.time()) + (hours * 3600)
    cache_table.put_item(
        Item={
            "cache_key": cache_key,
            "response": response_text,
            "ttl": ttl,
        }
    )
    log_event("info", "cache_saved", cache_key=cache_key, ttl=ttl)


def check_and_increment_usage(user_id, limit=20):
    today = datetime.utcnow().strftime("%Y-%m-%d")

    result = usage_table.get_item(Key={"user_id": user_id})
    item = result.get("Item")

    if not item or item.get("last_reset_date") != today:
        usage_table.put_item(
            Item={
                "user_id": user_id,
                "daily_calls": 1,
                "last_reset_date": today,
            }
        )
        return True

    daily_calls = int(item.get("daily_calls", 0))
    if daily_calls >= limit:
        return False

    usage_table.update_item(
        Key={"user_id": user_id},
        UpdateExpression="SET daily_calls = daily_calls + :inc",
        ExpressionAttributeValues={":inc": 1},
    )
    return True


def invoke_bedrock_text(user_id, prompt, max_tokens, subscription_tier="free"):
    limit = get_ai_limit_for_tier(subscription_tier)
    if not check_and_increment_usage(user_id, limit=limit):
        log_event(
            "warn",
            "usage_limit_exceeded",
            user_id=user_id,
            tier=subscription_tier,
            daily_limit=limit,
        )
        raise UsageLimitExceeded("Upgrade plan to continue")

    # Support both Claude and Nova models
    if "anthropic.claude" in BEDROCK_MODEL_ID:
        # Claude API format
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "messages": [
                {
                    "role": "user",
                    "content": [{"type": "text", "text": prompt}],
                }
            ],
            "max_tokens": max_tokens,
        }
    else:
        # Nova/Titan API format
        body = {
            "messages": [
                {
                    "role": "user",
                    "content": [{"text": prompt}],
                }
            ],
            "inferenceConfig": {
                "max_new_tokens": max_tokens,
                "temperature": 0.7,
            }
        }
    
    try:
        response = bedrock.invoke_model(modelId=BEDROCK_MODEL_ID, body=json.dumps(body))
        result = json.loads(response["body"].read())
        
        # Parse response based on model type
        if "anthropic.claude" in BEDROCK_MODEL_ID:
            content = result.get("content", [])
            if content and isinstance(content, list):
                text = content[0].get("text", "").strip()
            else:
                text = ""
        else:
            # Nova/Titan response format
            output = result.get("output", {})
            message = output.get("message", {})
            content = message.get("content", [])
            if content and isinstance(content, list):
                text = content[0].get("text", "").strip()
            else:
                text = ""
        
        if text:
            log_event(
                "info",
                "bedrock_invoke_ok",
                user_id=user_id,
                tier=subscription_tier,
                model=BEDROCK_MODEL_ID,
                max_tokens=max_tokens,
            )
            return text
        
        log_event("warn", "bedrock_empty_response", user_id=user_id, tier=subscription_tier)
        return ""
    except Exception as error:
        error_msg = str(error)
        log_event(
            "error",
            "bedrock_invoke_failed",
            user_id=user_id,
            tier=subscription_tier,
            model=BEDROCK_MODEL_ID,
            error=error_msg,
        )
        # Return empty string to trigger fallback logic
        return ""


def json_response(status_code, body):
    # Convert Decimal to float for JSON serialization
    def decimal_default(obj):
        if isinstance(obj, Decimal):
            return float(obj)
        raise TypeError
    
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "OPTIONS,POST",
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
        },
        "body": json.dumps(body, default=decimal_default),
    }


def parse_event(event):
    if isinstance(event, dict) and "body" in event:
        body = event.get("body")
        if isinstance(body, str):
            body = body.strip()
            return json.loads(body) if body else {}
        if isinstance(body, dict):
            return body
    return event if isinstance(event, dict) else {}


def calculate_priority(mastery, exam_weight, dependency_urgency):
    mastery = max(0, min(100, int(mastery)))
    exam_weight = max(1, min(10, int(exam_weight)))
    dependency_urgency = max(0, min(100, int(dependency_urgency)))
    priority = ((100 - mastery) * 0.6) + (exam_weight * 0.3) + (dependency_urgency * 0.1)
    return Decimal(str(round(priority, 2)))


def get_user_progress(user_id):
    response = progress_table.query(KeyConditionExpression=Key("user_id").eq(user_id))
    return response.get("Items", [])


def get_mastery_lookup(progress_items):
    return {
        item.get("concept_id"): int(item.get("mastery_score", 0))
        for item in progress_items
        if item.get("concept_id")
    }


def save_study_plan(user_id, recommendations):
    today = datetime.utcnow().strftime("%Y-%m-%d")
    top_recommendations = recommendations[:3]
    study_plan_table.put_item(
        Item={
            "user_id": user_id,
            "date": today,
            "recommended_concepts": top_recommendations,
            "reasoning": "Adaptive recalculated plan",
        }
    )
    return today, top_recommendations


def generate_recommendations(user_id):
    progress_items = get_user_progress(user_id)
    mastery_lookup = get_mastery_lookup(progress_items)

    recommendations = []
    for concept_id, mastery in mastery_lookup.items():
        concept_data = concepts_table.get_item(Key={"concept_id": concept_id}).get("Item", {})
        exam_weight = int(concept_data.get("exam_weight", 5))
        prerequisites = concept_data.get("prerequisites", [])

        dependency_urgency = 0
        blocked = False
        for prereq in prerequisites:
            prereq_mastery = mastery_lookup.get(prereq, 0)
            if prereq_mastery < 50:
                blocked = True
            if prereq_mastery < 70:
                dependency_urgency += 70 - prereq_mastery

        if blocked:
            continue

        score = calculate_priority(mastery, exam_weight, dependency_urgency)
        recommendations.append(
            {
                "concept_id": concept_id,
                "priority_score": score,
                "reason": f"Mastery {mastery}, Weight {exam_weight}",
            }
        )

    recommendations.sort(key=lambda x: x["priority_score"], reverse=True)
    return recommendations


def update_mastery(user_id, concept_id, quiz_score):
    safe_quiz_score = max(0, min(100, int(quiz_score)))
    existing = progress_table.get_item(
        Key={"user_id": user_id, "concept_id": concept_id}
    ).get("Item", {})
    previous_mastery = int(existing.get("mastery_score", 0))
    previous_attempts = int(existing.get("attempts", 0))
    previous_avg_time = float(existing.get("average_time_per_question", 0))
    previous_distribution = existing.get("mistake_type_distribution", {})
    if not isinstance(previous_distribution, dict):
        previous_distribution = {}

    improvement_trend = safe_quiz_score - previous_mastery
    confidence_score = round((safe_quiz_score * 0.7) + (min(previous_attempts + 1, 10) * 3), 2)

    progress_table.put_item(
        Item={
            "user_id": user_id,
            "concept_id": concept_id,
            "mastery_score": safe_quiz_score,
            "attempts": previous_attempts + 1,
            "improvement_trend": improvement_trend,
            "mistake_type_distribution": previous_distribution,
            "average_time_per_question": previous_avg_time,
            "confidence_score": confidence_score,
            "last_updated": datetime.utcnow().strftime("%Y-%m-%d"),
        }
    )
    return safe_quiz_score


def classify_mistake(user_id, question, student_answer, correct_answer, subscription_tier="free"):
    prompt = (
        "You are an expert exam error analyst.\n\n"
        f"Question: {question}\n"
        f"Student Answer: {student_answer}\n"
        f"Correct Answer: {correct_answer}\n\n"
        "Classify the mistake into one category only:\n"
        "- conceptual\n"
        "- formula_recall\n"
        "- calculation\n"
        "- application_logic\n"
        "- exam_trap\n\n"
        "Return only the category token, no extra text.\n"
    )

    ai_text = invoke_bedrock_text(
        user_id=user_id,
        prompt=prompt,
        max_tokens=100,
        subscription_tier=subscription_tier,
    )
    if not ai_text:
        return "conceptual"

    category = ai_text.strip().lower()
    category = re.sub(r"[^a-z_]", "", category)
    if category in MISTAKE_CATEGORIES:
        return category
    return "conceptual"


def store_mistake_log(
    user_id,
    concept_id,
    question_type,
    mistake_category,
    confidence_level=None,
    time_taken=None,
):
    timestamp = datetime.utcnow().isoformat(timespec="milliseconds") + "Z"
    item = {
        "user_id": user_id,
        "timestamp": timestamp,
        "concept_id": concept_id,
        "question_type": question_type or "unknown",
        "mistake_category": mistake_category,
        "confidence_level": int(confidence_level) if confidence_level is not None else 50,
        "time_taken": float(time_taken) if time_taken is not None else 0.0,
    }
    mistake_logs_table.put_item(Item=item)
    return item


def update_progress_after_mistake(
    user_id, concept_id, mistake_category, confidence_level=None, time_taken=None
):
    progress = progress_table.get_item(Key={"user_id": user_id, "concept_id": concept_id}).get("Item", {})
    distribution = progress.get("mistake_type_distribution", {})
    if not isinstance(distribution, dict):
        distribution = {}

    for category in MISTAKE_CATEGORIES:
        distribution[category] = int(distribution.get(category, 0))
    distribution[mistake_category] = int(distribution.get(mistake_category, 0)) + 1

    attempts = int(progress.get("attempts", 1))
    average_time = float(progress.get("average_time_per_question", 0))
    if time_taken is not None:
        try:
            safe_time = max(0.0, float(time_taken))
            average_time = round(((average_time * max(attempts - 1, 0)) + safe_time) / max(attempts, 1), 2)
        except (TypeError, ValueError):
            pass

    confidence_score = float(progress.get("confidence_score", 0))
    if confidence_level is not None:
        try:
            safe_confidence = max(0.0, min(100.0, float(confidence_level)))
            confidence_score = round((confidence_score * 0.7) + (safe_confidence * 0.3), 2)
        except (TypeError, ValueError):
            pass

    progress_table.update_item(
        Key={"user_id": user_id, "concept_id": concept_id},
        UpdateExpression=(
            "SET mistake_type_distribution = :distribution, "
            "average_time_per_question = :avg_time, "
            "confidence_score = :confidence, "
            "last_updated = :last_updated"
        ),
        ExpressionAttributeValues={
            ":distribution": distribution,
            ":avg_time": average_time,
            ":confidence": confidence_score,
            ":last_updated": datetime.utcnow().strftime("%Y-%m-%d"),
        },
    )


def calculate_trend(user_id):
    response = progress_table.query(KeyConditionExpression=Key("user_id").eq(user_id))
    items = response.get("Items", [])
    improvements = [int(item.get("mastery_score", 0)) for item in items]

    if len(improvements) < 2:
        return "insufficient_data"

    slope = (improvements[-1] - improvements[0]) / len(improvements)

    if slope > 2:
        return "strong_growth"
    if slope > 0:
        return "slow_growth"
    if slope == 0:
        return "stagnant"
    return "declining"


def get_notebook(user_id, concept_id):
    return notebook_table.get_item(
        Key={"user_id": user_id, "concept_id": concept_id}
    ).get("Item", {})


def upsert_notebook(user_id, concept_id, notes, mistakes, ai_summary):
    existing = get_notebook(user_id, concept_id)
    item = {
        "user_id": user_id,
        "concept_id": concept_id,
        "notes": notes if notes is not None else existing.get("notes", ""),
        "mistakes": mistakes if mistakes is not None else existing.get("mistakes", []),
        "ai_summary": ai_summary if ai_summary is not None else existing.get("ai_summary", ""),
        "last_updated": datetime.utcnow().strftime("%Y-%m-%d"),
    }
    notebook_table.put_item(Item=item)
    return item


def fallback_summary(concept_id, notes, mistakes, mastery, weak_prereqs):
    traps = ", ".join(mistakes[:3]) if mistakes else "common sign and substitution errors"
    weak = ", ".join(weak_prereqs) if weak_prereqs else "none"
    return (
        f"{concept_id.title()} quick summary: Focus on core definitions first, then standard problem types. "
        f"Current mastery is {mastery}/100. Common traps: {traps}. "
        f"Weak prerequisite areas: {weak}. "
        "For exam attempts, start with base formulas, validate domain/conditions, and check edge cases before finalizing."
    )


def generate_ai_summary(user_id, concept_id, notes, mistakes, subscription_tier="free"):
    concept = concepts_table.get_item(Key={"concept_id": concept_id}).get("Item", {})
    mastery_item = progress_table.get_item(
        Key={"user_id": user_id, "concept_id": concept_id}
    ).get("Item", {})
    mastery = int(mastery_item.get("mastery_score", 0))
    prereqs = concept.get("prerequisites", [])
    mastery_lookup = get_mastery_lookup(get_user_progress(user_id))
    weak_prereqs = [p for p in prereqs if mastery_lookup.get(p, 0) < 50]

    cache_key = build_cache_key(
        request_type="concept-summary",
        user_id=user_id,
        concept_id=concept_id,
        mastery=mastery,
    )
    cached = get_cached_response(cache_key)
    if cached:
        return cached.get("response", "")

    prompt = (
        "You are an exam-focused JEE tutor.\n\n"
        "Create a concise and reliable summary using this exact structure:\n"
        "1) Concept in one line\n"
        "2) Key idea bullets (max 4)\n"
        "3) Exam trap warning\n"
        "4) Quick revision checklist (3 items)\n\n"
        f"Concept: {concept_id}\n"
        f"Topic: {concept.get('topic', concept_id)}\n"
        f"User mastery: {mastery}/100\n"
        f"Weak prerequisites: {weak_prereqs}\n"
        f"User notes: {notes or ''}\n"
        f"User mistakes: {mistakes or []}\n"
    )
    ai_text = invoke_bedrock_text(
        user_id=user_id,
        prompt=prompt,
        max_tokens=450,
        subscription_tier=subscription_tier,
    )
    if ai_text:
        save_to_cache(cache_key, ai_text, hours=6)
        return ai_text
    return fallback_summary(concept_id, notes, mistakes or [], mastery, weak_prereqs)


def build_ai_context(user_id, concept_id):
    concept_data = concepts_table.get_item(Key={"concept_id": concept_id}).get("Item", {})
    topic = concept_data.get("topic", concept_id)
    prerequisites = concept_data.get("prerequisites", [])
    exam_weight = int(concept_data.get("exam_weight", 5))

    mastery_data = progress_table.get_item(
        Key={"user_id": user_id, "concept_id": concept_id}
    ).get("Item", {})
    mastery = int(mastery_data.get("mastery_score", 50))

    prereq_mastery_info = []
    weak_prerequisites = []
    for prereq in prerequisites:
        data = progress_table.get_item(
            Key={"user_id": user_id, "concept_id": prereq}
        ).get("Item", {})
        prereq_mastery = int(data.get("mastery_score", 0))
        prereq_mastery_info.append({"concept": prereq, "mastery": prereq_mastery})
        if prereq_mastery < 50:
            weak_prerequisites.append(prereq)

    notebook = get_notebook(user_id, concept_id)
    mistakes = notebook.get("mistakes", [])
    notes = notebook.get("notes", "")

    return {
        "user_id": user_id,
        "topic": topic,
        "concept_id": concept_id,
        "mastery": mastery,
        "exam_weight": exam_weight,
        "prerequisites": prereq_mastery_info,
        "weak_prerequisites": weak_prerequisites,
        "notes": notes,
        "mistakes": mistakes if isinstance(mistakes, list) else [],
        "dependency_position": {
            "direct_prerequisite_count": len(prerequisites),
        },
    }


def generate_ai_help(context, subscription_tier="free"):
    cache_key = build_cache_key(
        request_type="ai-help",
        user_id=context.get("user_id", ""),
        concept_id=context.get("concept_id", ""),
        mastery=context.get("mastery", 50),
    )
    cached = get_cached_response(cache_key)
    if cached:
        return cached.get("response", "")

    prereq_lines = (
        "\n".join(
            f"- {item.get('concept')}: mastery {item.get('mastery', 0)}/100"
            for item in context.get("prerequisites", [])
        )
        or "- none"
    )
    mistakes = context.get("mistakes", [])
    mistakes_line = ", ".join(mistakes[:5]) if mistakes else "none recorded"

    prompt = (
        "You are an expert JEE tutor.\n"
        "Return consistent output using these sections only:\n"
        "EXPLANATION\n"
        "PREREQUISITE_FIX\n"
        "EXAM_TRAP\n"
        "PRACTICE_QUESTIONS\n"
        "DIAGRAM_GUIDE\n\n"
        f"Topic: {context.get('topic', '')}\n"
        f"Student Mastery: {context.get('mastery', 50)}/100\n"
        f"Exam Weight Importance: {context.get('exam_weight', 5)}/10\n"
        f"Dependency Position (direct prerequisites): {context.get('dependency_position', {}).get('direct_prerequisite_count', 0)}\n"
        f"Weak prerequisites: {context.get('weak_prerequisites', [])}\n"
        f"Past mistakes: {mistakes_line}\n"
        f"Student notes: {context.get('notes', '')}\n\n"
        "Prerequisite Performance:\n"
        f"{prereq_lines}\n\n"
        "Instructions:\n"
        "- Explain in simple language.\n"
        "- Reinforce weak prerequisites first.\n"
        "- Include one exam trap warning.\n"
        "- Add exactly 3 conceptual practice questions.\n"
        "- Add a simple diagram structure description.\n"
    )

    ai_text = invoke_bedrock_text(
        user_id=context.get("user_id", ""),
        prompt=prompt,
        max_tokens=700,
        subscription_tier=subscription_tier,
    )
    if ai_text:
        save_to_cache(cache_key, ai_text, hours=6)
    return ai_text


def build_question_strategy(context):
    mastery = int(context.get("mastery", 50))

    if mastery < 40:
        difficulty = "easy_to_medium"
        focus = "concept_clarity"
    elif mastery < 70:
        difficulty = "medium"
        focus = "application"
    else:
        difficulty = "advanced"
        focus = "exam_traps"

    return {"difficulty": difficulty, "focus": focus}


def generate_questions(context, subscription_tier="free"):
    strategy = build_question_strategy(context)
    cache_key = build_cache_key(
        request_type="generate-questions",
        user_id=context.get("user_id", ""),
        concept_id=context.get("concept_id", ""),
        mastery=context.get("mastery", 50),
        extra={"difficulty": strategy.get("difficulty"), "focus": strategy.get("focus")},
    )
    cached = get_cached_response(cache_key)
    if cached:
        return cached.get("response", "")

    prereq_lines = (
        "\n".join(
            f"- {item.get('concept')}: mastery {item.get('mastery', 0)}/100"
            for item in context.get("prerequisites", [])
        )
        or "- none"
    )

    prompt = (
        "You are an expert JEE mathematics question designer.\n\n"
        f"Topic: {context.get('topic', '')}\n"
        f"Student Mastery: {context.get('mastery', 50)}/100\n"
        f"Difficulty Level: {strategy.get('difficulty')}\n"
        f"Focus Area: {strategy.get('focus')}\n"
        f"Exam Weight: {context.get('exam_weight', 5)}/10\n"
        "Prerequisite Performance:\n"
        f"{prereq_lines}\n\n"
        "Output format (strict):\n"
        "CONCEPTUAL_QUESTIONS\n"
        "APPLICATION_PROBLEMS\n"
        "TRAP_QUESTION\n"
        "DIAGRAM_QUESTION\n"
        "DIAGRAM_DATA\n\n"
        "Generate:\n"
        "- 2 conceptual questions\n"
        "- 2 numerical/application problems\n"
        "- 1 tricky exam trap question\n"
        "- 1 diagram-based question\n\n"
        "Rules:\n"
        "- Do NOT repeat common textbook examples\n"
        "- Vary structure\n"
        "- Use real exam thinking style\n"
        "- Provide solutions after each question\n"
        "- For the diagram question, return a structured JSON block in this format:\n"
        "  {\n"
        "    \"diagram_type\": \"\",\n"
        "    \"components\": [],\n"
        "    \"visual_description\": \"\"\n"
        "  }\n"
        "- Allowed diagram types: graph, geometric_shape, function_curve, coordinate_plane, flow_structure\n"
        "- Return the diagram JSON separately under a section titled exactly: DIAGRAM_DATA\n"
        "- Ensure problems are unique and not generic\n"
    )

    ai_text = invoke_bedrock_text(
        user_id=context.get("user_id", ""),
        prompt=prompt,
        max_tokens=900,
        subscription_tier=subscription_tier,
    )
    if ai_text:
        save_to_cache(cache_key, ai_text, hours=6)
    return ai_text


def extract_diagram_data(ai_text):
    if not ai_text:
        return None

    marker_match = re.search(r"DIAGRAM_DATA", ai_text)
    if not marker_match:
        return None

    start_search = marker_match.end()
    brace_start = ai_text.find("{", start_search)
    if brace_start == -1:
        return None

    depth = 0
    for index in range(brace_start, len(ai_text)):
        char = ai_text[index]
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                json_blob = ai_text[brace_start : index + 1]
                try:
                    return json.loads(json_blob)
                except (json.JSONDecodeError, TypeError, ValueError):
                    return None
    return None


def analyze_performance(user_id):
    response = progress_table.query(KeyConditionExpression=Key("user_id").eq(user_id))
    items = response.get("Items", [])

    total_mastery = 0
    high_weight_mastery = 0
    high_weight_count = 0
    stagnation_flags = 0
    average_confidence = 0
    low_mastery_concepts = []

    for item in items:
        mastery = int(item.get("mastery_score", 0))
        total_mastery += mastery
        average_confidence += float(item.get("confidence_score", 0))

        concept_data = concepts_table.get_item(Key={"concept_id": item.get("concept_id")}).get("Item", {})
        exam_weight = int(concept_data.get("exam_weight", 5))

        if exam_weight >= 8:
            high_weight_mastery += mastery
            high_weight_count += 1

        if mastery < 50:
            stagnation_flags += 1
            low_mastery_concepts.append(item.get("concept_id"))

    avg_mastery = total_mastery / len(items) if items else 0
    high_weight_avg = high_weight_mastery / high_weight_count if high_weight_count else 0
    avg_confidence = average_confidence / len(items) if items else 0
    exam_readiness = (avg_mastery * 0.7) + (high_weight_avg * 0.3)

    return {
        "average_mastery": round(avg_mastery, 2),
        "high_weight_mastery": round(high_weight_avg, 2),
        "average_confidence": round(avg_confidence, 2),
        "exam_readiness_score": round(exam_readiness, 2),
        "trajectory": calculate_trend(user_id),
        "stagnation_risk": stagnation_flags > 2,
        "stagnation_count": stagnation_flags,
        "at_risk_concepts": low_mastery_concepts[:5],
    }


def generate_strategy_report(user_id, subscription_tier="free"):
    performance = analyze_performance(user_id)
    cache_key = build_cache_key(
        request_type="ai-strategy",
        user_id=user_id,
        concept_id="global",
        mastery=round(performance.get("average_mastery", 0)),
        extra={
            "readiness": performance.get("exam_readiness_score", 0),
            "trajectory": performance.get("trajectory", "insufficient_data"),
            "stagnation": performance.get("stagnation_count", 0),
        },
    )
    cached = get_cached_response(cache_key)
    if cached:
        return cached.get("response", "")

    prompt = (
        "You are an AI exam strategist.\n\n"
        "Return structured output with sections:\n"
        "READINESS\n"
        "RISK_LEVEL\n"
        "FIVE_DAY_PLAN\n"
        "TIME_ALLOCATION\n"
        "CONFIDENCE_GUIDANCE\n\n"
        "Performance Data:\n"
        f"{performance}\n\n"
        "Provide:\n"
        "- Overall readiness assessment\n"
        "- Risk level\n"
        "- 5-day strategic improvement plan\n"
        "- Study time allocation advice\n"
        "- Psychological advice for confidence\n\n"
        "Be concise but strategic.\n"
    )

    ai_text = invoke_bedrock_text(
        user_id=user_id,
        prompt=prompt,
        max_tokens=700,
        subscription_tier=subscription_tier,
    )
    if ai_text:
        save_to_cache(cache_key, ai_text, hours=6)
    return ai_text


def update_learning_memory(user_id, subscription_tier="free"):
    performance = analyze_performance(user_id)
    recent_logs = mistake_logs_table.query(
        KeyConditionExpression=Key("user_id").eq(user_id),
        ScanIndexForward=False,
        Limit=25,
    ).get("Items", [])

    category_counts = {}
    for log in recent_logs:
        category = log.get("mistake_category", "conceptual")
        category_counts[category] = int(category_counts.get(category, 0)) + 1

    prompt = (
        "Based on student's recent performance, summarize:\n"
        "- Recurring mistake patterns\n"
        "- Weak conceptual areas\n"
        "- Confidence level\n"
        "- Learning behavior traits\n\n"
        "Keep structured summary.\n\n"
        f"Performance data: {performance}\n"
        f"Recent mistake category counts: {category_counts}\n"
    )

    summary = invoke_bedrock_text(
        user_id=user_id,
        prompt=prompt,
        max_tokens=500,
        subscription_tier=subscription_tier,
    )

    memory_table.put_item(
        Item={
            "user_id": user_id,
            "memory_type": "learning_profile",
            "content": summary,
            "last_updated": datetime.utcnow().isoformat() + "Z",
        }
    )

    return {"memory_type": "learning_profile", "content": summary}


def lambda_handler(event, context):
    request_id = getattr(context, "aws_request_id", "local")
    method = event.get("requestContext", {}).get("http", {}).get("method", "")
    path = event.get("rawPath", "")
    log_event("info", "request_received", request_id=request_id, method=method, path=path)
    if method == "OPTIONS":
        return json_response(200, {"ok": True})

    try:
        payload = parse_event(event)
    except (json.JSONDecodeError, ValueError):
        log_event("warn", "invalid_json_body", request_id=request_id, path=path)
        return json_response(400, {"error": "Invalid JSON body"})

    # Public endpoints that don't require authentication
    if path == "/register":
        username = payload.get("username")
        password = payload.get("password")
        role = payload.get("role", "student")
        grade = payload.get("grade")
        
        if not username or not password:
            return json_response(400, {"error": "username and password are required"})
        
        # Generate user_id from username
        user_id = username.lower().replace(" ", "_")
        
        # Check if user already exists
        existing_user = users_table.get_item(Key={"user_id": user_id}).get("Item")
        if existing_user:
            return json_response(409, {"error": "User already exists"})
        
        # Create new user (in production, hash the password!)
        users_table.put_item(
            Item={
                "user_id": user_id,
                "username": username,
                "password": password,  # WARNING: In production, use bcrypt or similar!
                "role": role,
                "grade": int(grade) if grade else None,
                "subscription_tier": "free",
                "created_at": datetime.utcnow().isoformat() + "Z"
            }
        )
        
        log_event("info", "user_registered", user_id=user_id, role=role)
        return json_response(201, {
            "user_id": user_id,
            "username": username,
            "role": role,
            "grade": grade,
            "message": "User registered successfully"
        })
    
    if path == "/login":
        username = payload.get("username")
        password = payload.get("password")
        
        if not username or not password:
            return json_response(400, {"error": "username and password are required"})
        
        # Generate user_id from username
        user_id = username.lower().replace(" ", "_")
        
        # Get user from database
        user = users_table.get_item(Key={"user_id": user_id}).get("Item")
        if not user:
            return json_response(401, {"error": "Invalid credentials"})
        
        # Check password (in production, use proper password hashing!)
        if user.get("password") != password:
            return json_response(401, {"error": "Invalid credentials"})
        
        log_event("info", "user_logged_in", user_id=user_id)
        return json_response(200, {
            "user_id": user_id,
            "username": user.get("username"),
            "role": user.get("role", "student"),
            "grade": user.get("grade"),
            "subscription_tier": user.get("subscription_tier", "free"),
            "message": "Login successful"
        })
    
    if path == "/auth/google":
        # Google OAuth login/signup
        google_user_info = payload.get("google_user_info")
        
        if not google_user_info:
            return json_response(400, {"error": "google_user_info is required"})
        
        email = google_user_info.get("email")
        google_id = google_user_info.get("sub") or google_user_info.get("google_id")
        name = google_user_info.get("name", "")
        picture = google_user_info.get("picture", "")
        
        if not email or not google_id:
            return json_response(400, {"error": "Invalid Google user info"})
        
        # Check if user exists by google_id
        # Since DynamoDB doesn't support querying by non-key attributes easily,
        # we'll use email as username for Google users
        user_id = email.lower().replace("@", "_at_").replace(".", "_")
        
        # Try to get existing user
        user = users_table.get_item(Key={"user_id": user_id}).get("Item")
        
        if user:
            # Update google_id if not set
            if not user.get("google_id"):
                users_table.update_item(
                    Key={"user_id": user_id},
                    UpdateExpression="SET google_id = :gid, profile_picture = :pic",
                    ExpressionAttributeValues={
                        ":gid": google_id,
                        ":pic": picture
                    }
                )
            
            log_event("info", "google_user_logged_in", user_id=user_id)
            return json_response(200, {
                "user_id": user_id,
                "username": user.get("username", name),
                "role": user.get("role", "student"),
                "grade": user.get("grade"),
                "subscription_tier": user.get("subscription_tier", "free"),
                "email": email,
                "picture": picture,
                "message": "Login successful"
            })
        
        # Create new user
        username = name or email.split("@")[0]
        users_table.put_item(
            Item={
                "user_id": user_id,
                "username": username,
                "password": "GOOGLE_AUTH",  # No password for Google users
                "role": "student",
                "google_id": google_id,
                "profile_picture": picture,
                "subscription_tier": "free",
                "created_at": datetime.utcnow().isoformat() + "Z"
            }
        )
        
        log_event("info", "google_user_registered", user_id=user_id)
        return json_response(201, {
            "user_id": user_id,
            "username": username,
            "role": "student",
            "grade": None,
            "subscription_tier": "free",
            "email": email,
            "picture": picture,
            "message": "User registered successfully"
        })

    # All other endpoints require user_id
    user_id = payload.get("user_id")
    if not user_id:
        log_event("warn", "missing_user_id", request_id=request_id, path=path)
        return json_response(400, {"error": "user_id is required"})

    try:
        user = users_table.get_item(Key={"user_id": user_id}).get("Item")
    except Exception as error:
        log_event("error", "users_lookup_failed", request_id=request_id, user_id=user_id, path=path, message=str(error))
        return json_response(500, {"error": "User lookup failed"})
    
    # Auto-create guest users for /ask endpoint
    if not user and path == "/ask":
        log_event("info", "auto_creating_guest_user", user_id=user_id)
        try:
            users_table.put_item(
                Item={
                    "user_id": user_id,
                    "username": user_id,
                    "role": "student",
                    "subscription_tier": "free",
                    "created_at": datetime.utcnow().isoformat() + "Z"
                }
            )
            user = {
                "user_id": user_id,
                "username": user_id,
                "role": "student",
                "subscription_tier": "free"
            }
        except Exception as error:
            log_event("error", "guest_user_creation_failed", user_id=user_id, error=str(error))
            return json_response(500, {"error": "Failed to create guest user"})
    elif not user:
        log_event("warn", "user_not_found", request_id=request_id, user_id=user_id, path=path)
        return json_response(404, {"error": f"User '{user_id}' not found"})
    
    subscription_tier = normalize_tier(user.get("subscription_tier", "free"))
    log_event(
        "info",
        "request_user_context",
        request_id=request_id,
        user_id=user_id,
        path=path,
        subscription_tier=subscription_tier,
    )

    if path == "/recommend":
        recommendations = generate_recommendations(user_id)
        date, top_recommendations = save_study_plan(user_id, recommendations)
        return json_response(
            200,
            {
                "user_id": user_id,
                "date": date,
                "recommendations": top_recommendations,
            },
        )

    if path == "/update-progress":
        concept_id = payload.get("concept_id")
        quiz_score = payload.get("quiz_score")
        if not concept_id:
            return json_response(400, {"error": "concept_id is required"})
        if quiz_score is None:
            return json_response(400, {"error": "quiz_score is required"})

        try:
            new_mastery = update_mastery(user_id, concept_id, quiz_score)
        except (TypeError, ValueError):
            return json_response(400, {"error": "quiz_score must be a number"})

        logged_mistake = None
        question = payload.get("question")
        student_answer = payload.get("student_answer")
        correct_answer = payload.get("correct_answer")
        if question and student_answer is not None and correct_answer is not None:
            if not has_tier_access(subscription_tier, "pro"):
                logged_mistake = {"error": "Upgrade to Pro for weakness classifier"}
            else:
                try:
                    mistake_category = classify_mistake(
                        user_id,
                        question,
                        student_answer,
                        correct_answer,
                        subscription_tier=subscription_tier,
                    )
                    logged_mistake = store_mistake_log(
                        user_id=user_id,
                        concept_id=concept_id,
                        question_type=payload.get("question_type", "quiz"),
                        mistake_category=mistake_category,
                        confidence_level=payload.get("confidence_level"),
                        time_taken=payload.get("time_taken"),
                    )
                    update_progress_after_mistake(
                        user_id=user_id,
                        concept_id=concept_id,
                        mistake_category=mistake_category,
                        confidence_level=payload.get("confidence_level"),
                        time_taken=payload.get("time_taken"),
                    )
                except UsageLimitExceeded:
                    logged_mistake = {"error": "Upgrade plan to continue"}
                except Exception:
                    logged_mistake = None

        recommendations = generate_recommendations(user_id)
        date, top_recommendations = save_study_plan(user_id, recommendations)
        return json_response(
            200,
            {
                "user_id": user_id,
                "concept_id": concept_id,
                "new_mastery": new_mastery,
                "date": date,
                "updated_plan": top_recommendations,
                "mistake_log": logged_mistake,
                "subscription_tier": subscription_tier,
            },
        )

    if path == "/notebook/get":
        concept_id = payload.get("concept_id")
        if not concept_id:
            return json_response(400, {"error": "concept_id is required"})
        return json_response(200, get_notebook(user_id, concept_id))

    if path == "/notebook/upsert":
        concept_id = payload.get("concept_id")
        if not concept_id:
            return json_response(400, {"error": "concept_id is required"})
        notes = payload.get("notes")
        mistakes = payload.get("mistakes")
        ai_summary = payload.get("ai_summary")
        if mistakes is not None and not isinstance(mistakes, list):
            return json_response(400, {"error": "mistakes must be a list"})
        item = upsert_notebook(user_id, concept_id, notes, mistakes, ai_summary)
        return json_response(200, item)

    if path == "/notebook/summarize":
        concept_id = payload.get("concept_id")
        if not concept_id:
            return json_response(400, {"error": "concept_id is required"})
        notebook = get_notebook(user_id, concept_id)
        notes = payload.get("notes", notebook.get("notes", ""))
        mistakes = payload.get("mistakes", notebook.get("mistakes", []))
        if not isinstance(mistakes, list):
            return json_response(400, {"error": "mistakes must be a list"})
        try:
            ai_summary = generate_ai_summary(
                user_id,
                concept_id,
                notes,
                mistakes,
                subscription_tier=subscription_tier,
            )
        except UsageLimitExceeded:
            return json_response(429, {"error": "Upgrade plan to continue"})
        except Exception as error:
            log_event(
                "error",
                "notebook_summarize_failed",
                request_id=request_id,
                user_id=user_id,
                concept_id=concept_id,
                message=str(error),
            )
            return json_response(502, {"error": "summary_generation_failed"})
        item = upsert_notebook(user_id, concept_id, notes, mistakes, ai_summary)
        return json_response(
            200,
            {
                "concept_id": concept_id,
                "ai_summary": item.get("ai_summary", ""),
                "last_updated": item.get("last_updated"),
            },
        )

    if path == "/ai-help":
        concept_id = payload.get("concept_id")
        if not concept_id:
            return json_response(400, {"error": "concept_id is required"})

        context = build_ai_context(user_id, concept_id)

        try:
            ai_response = generate_ai_help(context, subscription_tier=subscription_tier)
        except UsageLimitExceeded:
            return json_response(429, {"error": "Upgrade plan to continue"})
        except Exception as error:
            return json_response(
                502,
                {
                    "error": "bedrock_invoke_failed",
                    "message": str(error),
                },
            )

        return json_response(
            200,
            {
                "concept_id": concept_id,
                "mastery_score": context.get("mastery", 50),
                "context": context,
                "ai_response": ai_response,
                "ai_explanation": ai_response,
                "subscription_tier": subscription_tier,
            },
        )

    if path == "/generate-questions":
        concept_id = payload.get("concept_id")
        if not concept_id:
            return json_response(400, {"error": "concept_id is required"})

        context = build_ai_context(user_id, concept_id)
        try:
            questions = generate_questions(context, subscription_tier=subscription_tier)
        except UsageLimitExceeded:
            return json_response(429, {"error": "Upgrade plan to continue"})
        except Exception as error:
            return json_response(
                502,
                {
                    "error": "bedrock_invoke_failed",
                    "message": str(error),
                },
            )

        return json_response(
            200,
            {
                "concept_id": concept_id,
                "strategy": build_question_strategy(context),
                "questions": questions,
                "diagram_data": extract_diagram_data(questions),
                "subscription_tier": subscription_tier,
            },
        )

    if path == "/performance-report":
        report = analyze_performance(user_id)
        return json_response(200, report)

    if path == "/trend-report":
        if not has_tier_access(subscription_tier, "pro"):
            return json_response(403, {"error": "Upgrade to Pro for trend prediction"})
        return json_response(200, {"trajectory": calculate_trend(user_id)})

    if path == "/classify-mistake":
        if not has_tier_access(subscription_tier, "pro"):
            return json_response(403, {"error": "Upgrade to Pro for weakness classifier"})
        concept_id = payload.get("concept_id")
        question = payload.get("question")
        student_answer = payload.get("student_answer")
        correct_answer = payload.get("correct_answer")
        if not concept_id:
            return json_response(400, {"error": "concept_id is required"})
        if not question or student_answer is None or correct_answer is None:
            return json_response(
                400,
                {"error": "question, student_answer, and correct_answer are required"},
            )

        try:
            mistake_category = classify_mistake(
                user_id,
                question,
                student_answer,
                correct_answer,
                subscription_tier=subscription_tier,
            )
            logged = store_mistake_log(
                user_id=user_id,
                concept_id=concept_id,
                question_type=payload.get("question_type", "quiz"),
                mistake_category=mistake_category,
                confidence_level=payload.get("confidence_level"),
                time_taken=payload.get("time_taken"),
            )
            update_progress_after_mistake(
                user_id=user_id,
                concept_id=concept_id,
                mistake_category=mistake_category,
                confidence_level=payload.get("confidence_level"),
                time_taken=payload.get("time_taken"),
            )
            return json_response(
                200,
                {
                    "mistake_category": mistake_category,
                    "mistake_log": logged,
                },
            )
        except UsageLimitExceeded:
            return json_response(429, {"error": "Upgrade plan to continue"})
        except Exception as error:
            return json_response(
                502,
                {
                    "error": "bedrock_invoke_failed",
                    "message": str(error),
                },
            )

    if path == "/ai-strategy":
        if not has_tier_access(subscription_tier, "pro"):
            return json_response(403, {"error": "Upgrade to Pro for AI strategy planner"})
        try:
            strategy = generate_strategy_report(user_id, subscription_tier=subscription_tier)
        except UsageLimitExceeded:
            return json_response(429, {"error": "Upgrade plan to continue"})
        except Exception as error:
            return json_response(
                502,
                {
                    "error": "bedrock_invoke_failed",
                    "message": str(error),
                },
            )
        return json_response(200, {"strategy": strategy})

    if path == "/update-learning-memory":
        if not has_tier_access(subscription_tier, "elite"):
            return json_response(403, {"error": "Upgrade to Elite for deep learning memory"})
        try:
            memory = update_learning_memory(user_id, subscription_tier=subscription_tier)
            return json_response(200, memory)
        except UsageLimitExceeded:
            return json_response(429, {"error": "Upgrade plan to continue"})
        except Exception as error:
            return json_response(
                502,
                {
                    "error": "bedrock_invoke_failed",
                    "message": str(error),
                },
            )

    if path == "/learning-memory":
        if not has_tier_access(subscription_tier, "elite"):
            return json_response(403, {"error": "Upgrade to Elite for deep learning memory"})
        memory_type = payload.get("memory_type", "learning_profile")
        memory = memory_table.get_item(
            Key={"user_id": user_id, "memory_type": memory_type}
        ).get("Item", {})
        return json_response(200, memory)

    # General Q&A endpoint - handles any question
    if path == "/ask":
        question = payload.get("question")
        if not question:
            return json_response(400, {"error": "question is required"})
        
        # Build a general-purpose prompt for any question
        prompt = (
            "You are an expert AI tutor and technical educator.\n\n"
            "Answer the following question clearly and comprehensively:\n\n"
            f"Question: {question}\n\n"
            "Provide a well-structured answer that includes:\n"
            "1. A clear, concise explanation\n"
            "2. Key concepts and definitions\n"
            "3. Practical examples where applicable\n"
            "4. Common misconceptions or pitfalls (if relevant)\n"
            "5. Real-world applications (if relevant)\n\n"
            "Keep the answer educational, accurate, and easy to understand.\n"
            "Use simple language but maintain technical accuracy.\n"
            "Format the response in clear paragraphs.\n"
        )
        
        try:
            answer = invoke_bedrock_text(
                user_id=user_id,
                prompt=prompt,
                max_tokens=1000,
                subscription_tier=subscription_tier,
            )
            
            # If Bedrock returns empty (due to access issues), provide helpful fallback
            if not answer:
                answer = (
                    "I'm currently unable to generate AI responses because AWS Bedrock model access needs to be configured. "
                    "However, I can help you with:\n\n"
                    "• Personalized learning recommendations based on your progress\n"
                    "• Study plan generation\n"
                    "• Performance analytics and insights\n"
                    "• Progress tracking across concepts\n\n"
                    "For your question about: " + question + "\n\n"
                    "Please check the AWS Console to enable Bedrock model access, or use the other features available in the dashboard."
                )
            
            return json_response(200, {
                "question": question,
                "answer": answer,
                "timestamp": datetime.utcnow().isoformat() + "Z"
            })
        except UsageLimitExceeded:
            return json_response(429, {"error": "Daily limit reached. Upgrade your plan to continue."})
        except Exception as error:
            log_event(
                "error",
                "ask_endpoint_failed",
                request_id=request_id,
                user_id=user_id,
                question=question[:100],
                message=str(error),
            )
            # Provide helpful fallback instead of error
            return json_response(200, {
                "question": question,
                "answer": (
                    "I'm currently unable to generate AI responses. "
                    "This may be due to AWS Bedrock configuration. "
                    "Please try using the other features like recommendations, study plans, and progress tracking."
                ),
                "timestamp": datetime.utcnow().isoformat() + "Z"
            })

    # Question API endpoints
    if path.startswith("/api/questions/concept/"):
        # GET /api/questions/concept/{concept_id}
        concept_id = path.split("/")[-1]
        try:
            concept_id = int(concept_id)
        except ValueError:
            return json_response(400, {"error": "concept_id must be an integer"})
        
        # For now, return empty list - will be populated with actual questions later
        return json_response(200, {
            "concept_id": concept_id,
            "count": 0,
            "questions": []
        })
    
    if path.startswith("/api/questions/") and path.count("/") == 3:
        # GET /api/questions/{question_id}
        question_id = path.split("/")[-1]
        try:
            question_id = int(question_id)
        except ValueError:
            return json_response(400, {"error": "question_id must be an integer"})
        
        # For now, return not found - will be populated with actual questions later
        return json_response(404, {
            "error": "Question not found",
            "question_id": question_id
        })

    log_event("warn", "invalid_route", request_id=request_id, user_id=user_id, path=path)
    return json_response(400, {"error": "Invalid route"})
